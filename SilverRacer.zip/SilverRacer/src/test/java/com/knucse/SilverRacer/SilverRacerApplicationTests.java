package com.knucse.SilverRacer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SilverRacerApplicationTests {

	@Test
	void contextLoads() {
	}

}
