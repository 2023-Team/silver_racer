package com.knucse.SilverRacer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SilverRacerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SilverRacerApplication.class, args);
	}

}
